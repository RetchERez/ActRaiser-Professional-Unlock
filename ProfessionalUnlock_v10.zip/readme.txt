ACTRAISER - PROFESSIONAL UNLOCK v1.0
By Retch

Unlock the original USA Professional mode from the start.

FEATURES

Professional Mode Available Immediately
PROFESSIONAL! is always visible at the title menu, without first completing
the game or moving the cursor. With fresh SRAM, press Down once from
NEW GAME to select it, then press Start.

Original Action-Only Campaign
Play the original action stages in their native order, including the Death
Heim boss rush and Professional ending, without town-building segments.

Original Professional Rules
Keep the original harder Professional settings, 24 starting HP, five lives,
and no magic. This patch unlocks that mode; it does not rebalance it.

Regular Game Retained
NEW GAME retains the full regular game with town building and normal
progression. CONTINUE remains available with a valid regular-game save.
This patch does not add saving to Professional mode.

ROM INFORMATION
Base game: ActRaiser (USA), SNES
ROM size: 1,048,576 bytes, without a copier header
Clean base CRC32: EAC3358D
Patched ROM CRC32: F2F081FF

INSTALLATION
Apply the included IPS patch to a clean copy of ActRaiser (USA) using an
IPS-compatible patcher. If your dump has a 512-byte copier header, remove it
first. Apply only this patch to that copy; do not combine the two patches.
The original game ROM is not included.

SPECIAL THANKS:
Mr. Elaine Marley
